# J00Ni-pycord-Example
Standard Bot fürs Bot Hosting

